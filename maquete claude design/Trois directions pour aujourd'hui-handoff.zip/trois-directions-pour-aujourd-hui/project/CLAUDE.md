# Bloc commun — contexte pour toutes les maquettes

## Produit
Application française de nutrition et de planification de repas. 100 % locale :
aucun compte, aucun serveur, aucune donnée envoyée, fonctionne hors-ligne.
Pas d'IA. Ce n'est PAS un tracker de calories et PAS une application médicale.

## Contrainte centrale : utilisable par toutes les tranches d'âge
Y compris des personnes peu à l'aise avec le numérique.
- Navigation permanente et visible. INTERDIT : menu hamburger, navigation cachée.
- Chaque icône est TOUJOURS accompagnée de son libellé texte.
- Cibles tactiles de 48 px minimum.
- Typographie en unités relatives, aucune hauteur figée : l'interface doit tenir
  si la police système est agrandie de 150 %.
- Contraste élevé, viser 7:1 sur le texte courant.
- Aucune action accessible uniquement par un geste : tout swipe a un bouton visible.
- Une seule action dominante par écran.

## Barre de navigation, présente sur TOUS les écrans
Cinq onglets en bas sur mobile, icônes distinctes, libellé sous chaque icône :
Aujourd'hui (assiette) · Semaine (calendrier) · Courses (panier) ·
Recettes (livre) · Savoir (ampoule)
Sur écran large : colonne à gauche, MÊME ordre, MÊMES libellés, MÊMES icônes.

## Direction visuelle
Chaleureux et sobre, éditorial plutôt que clinique. Neutres chauds, une seule
couleur d'accent. La photographie culinaire porte l'ambiance. Beaucoup d'air.
Mode clair et mode sombre.

## À proscrire absolument
- Compteur de calories, « il vous reste X kcal », objectif journalier
- Score global type A-E, Nutri-Score, code couleur rouge/vert sur les aliments
- Série, streak, badge, progression gamifiée
- Avatar, profil utilisateur, élément suggérant un compte en ligne
- Vocabulaire de jugement : « sain », « mauvais », « à éviter », « plaisir coupable »
